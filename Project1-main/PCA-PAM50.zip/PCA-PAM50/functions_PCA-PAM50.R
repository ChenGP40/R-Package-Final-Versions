#~~~~~~~ Libraries
message("##~~~ LOADING REQUIRED LIBs~~~")
library(gplots)
library(RColorBrewer)
library(lattice)
library(genefilter)
library(ctc)
library(heatmap.plus)
message("##~~~ DONE~~~")

###### modeling after plotPCA of DESeq 
my.plotPCA = function(x, intgroup, ablne = 0,colours = c("red","hotpink","darkblue","lightblue","red3","hotpink3","royalblue3","lightskyblue3"),LINE.V=T)
{
	message("Specify number to option colors as per the factors in condition")	
	pca = prcomp(t(exprs(x))) #[select,]
	fac = intgroup
    
	if(LINE.V){
		pcafig = xyplot(PC2 ~ (PC1*1), groups=fac, data=as.data.frame(pca$x),xlab="PC1",
		panel = function(...) {
		panel.xyplot(...)
		panel.abline(v=ablne,lty=3,lwd=1.5)
		}, 
		main = draw.key(key = list(rect = list(col = colours),text = list(levels(fac)), rep = FALSE)),
		pch=16, cex=2,aspect = "iso", col=colours)
	}else{
		pcafig = xyplot(PC2 ~ (PC1*1), groups=fac, data=as.data.frame(pca$x),xlab="PC1",
		panel = function(...) {
		panel.xyplot(...)
		#panel.abline(v=ablne,lty=3,lwd=1.5)
		}, 
		main = draw.key(key = list(rect = list(col = colours),text = list(levels(fac)), rep = FALSE)),
		pch=16, cex=2,aspect = "iso", col=colours)
	}
	

	
	
	return(pcafig)
}


#### function to form a ER-balance subet and derive its median---write it to PAM50 dir
makeCalls.ihc = function(df.cln = ih.flp, seed=118, mat = ml2, NM.mdns="Mdns.ihc", PAM50dir="./PAM50/bioclassifier_R/", 
			 mdns.outFile = "mediansPerDataset_09May18.txt"){
	message("###clinical subtype data.frame should have a column --PatientID-- with which mat cols are also named")
	message("##IHC subtype column should be named ---IHC---")
	
	
	ERN.ihc = df.cln[which(df.cln$IHC %in% c("TN","Her2+")),] ### get ER- samples data.frame
	dim(ERN.ihc)	#[1] 153   9

	ERP.ihc = df.cln[which(df.cln$IHC %in% c("LA","LB1","LB2")),]
	dim(ERP.ihc) #[1] 559   9
	
	set.seed(seed);i = sample(dim(ERP.ihc)[1],dim(ERN.ihc)[1]) # take equal number of ER+ and ER- samples
	length(ERP.ihc$PatientID[i]) # ER positive samples
	length(ERN.ihc$PatientID)    # ER negative samples

	######=== subset pam50 matrix with the IDs corresponding to balanced ER+ and ER-
	mbal.ihc = mat[,c(ERP.ihc$PatientID[i],ERN.ihc$PatientID)]

	dim(mbal.ihc) #[1]  50 306

	# Find median
	mdns      = apply(mbal.ihc,1,median,na.rm=T) # compute median of each row i.e gene
	mdns.df   = as.data.frame(mdns)
	df.mdns   = data.frame(X=rownames(mdns.df),mdns.ihc=mdns.df$mdns) # ER-blanced set based on IHC status alone--- 
	colnames(df.mdns) = c("X",NM.mdns)
	

	# merge this median to PAM50-medians file "mediansPerDataset_v2.txt"
	fl.nm     = paste(PAM50dir,"mediansPerDataset_v2.txt",sep="/")
	fl.mdn    = read.table(fl.nm,sep="\t",header=T,stringsAsFactors=F)

	df.al     = merge(fl.mdn,df.mdns,by="X")

	#save(df.al,file="./Rdat/mediansPerDataset_15Nov17.Rdat")
	write.table(df.al, file=paste(PAM50dir,mdns.outFile,sep="/"), sep="\t", col.names=T,row.names=F,quote=F)

	####
	# run the assignment algorithm
	# all the global variable required for assignment algorithm are set outside of function where it is been called
	####

	source(paste(paramDir,"subtypePrediction_functions.R",sep="/"))
	source(paste(paramDir,"subtypePrediction_distributed.R",sep="/"))

	ot.fl     = paste(inputDir,short,"_pam50scores.txt",sep="")
	kl        = read.table(ot.fl,sep="\t",header=T,stringsAsFactors=F)#note md -- for median centered

	df.kl     = data.frame(PatientID=kl$X,Int.SBS.ihcMd=kl$Call,stringsAsFactors=FALSE)
	colnames(df.kl) = c("PatientID",paste("Int.SBS",NM.mdns,sep="."))
	df.kl     = merge(df.kl,df.cln,by="PatientID")

	return(list(Int.sbs=df.kl, score.fl=kl, mdns.fl=df.al, SBS.colr = subtypeColors, outList=out))
}


#### function to form a ER-balance subet and derive its median---write it to PAM50 dir
makeCalls.PC1ihc = function(df.cln = ih.flp, seed=118, mat = ml2, NM.mdns="Mdns.PC1ihc", PAM50dir="./PAM50/bioclassifier_R/", 
			 mdns.outFile = "mediansPerDataset_PC1ihc_09May18.txt"){
	message("###clinical subtype data.frame should have a column --PatientID-- with which mat cols are also named")
	message("##IHC subtype column should be named ---IHC---")
	
	
	# Pull the PCA components

	
	#rv      = rowVars(mat)
	#select  = order(rv, decreasing = TRUE)[seq_len(dim(mat)[1])] # the input is PAM50 matrix --50 genes -- get from dimension
	pca     = prcomp(t(mat))#[select,]
	pc12    = pca$x[,1:2] #get two principal 
	df.pc1  = data.frame(PatientID=rownames(pc12),PC1 = pc12[,1],stringsAsFactors=F)
	df.pca1 = merge(df.cln,df.pc1,by="PatientID")

	### function to count the number of mis-classified cases on a given PC1 point ---find the cutoff
	getno = function(x){
		p.rgt = length(which(df.pca1$IHC %in% c("LB1","LB2","LA") & df.pca1$PC1 >x))/length(which(df.pca1$IHC %in% c("LB1","LB2","LA") ))
		n.lft = length(which(df.pca1$IHC %in% c("Her2+","TN") & df.pca1$PC1 <x))/ length(which(df.pca1$IHC %in% c("Her2+","TN")))
		tot   = (p.rgt + n.lft) * 100
		return(list(PC1=x,Mis=tot))
	}


	
	df.mis  = do.call(rbind.data.frame,lapply(seq(-20,20,by=0.1),getno))
	num.min = df.mis$PC1[which(df.mis$Mis == min(df.mis$Mis))]

	ERP.pc1ihc = df.pca1[which(df.pca1$IHC %in% c("LB1","LB2","LA") & df.pca1$PC1 <= mean(num.min)),] # used mean to overcome situation where there are two minimum
	ERN.pc1ihc = df.pca1[which(df.pca1$IHC %in% c("Her2+","TN") & df.pca1$PC1 > mean(num.min)),]
	
	dim(ERP.pc1ihc)#  543   3
	dim(ERN.pc1ihc)#  118   3

	set.seed(seed);i = sample(dim(ERP.pc1ihc)[1],dim(ERN.pc1ihc)[1]) # take equal number of ER+ and ER- samples
	length(ERP.pc1ihc$PatientID[i]) # ER positive samples
	length(ERN.pc1ihc$PatientID)    # ER negative samples

	######=== subset pam50 matrix with the IDs corresponding to balanced ER+ and ER-
	mbal.pc1ihc = mat[,c(ERP.pc1ihc$PatientID[i],ERN.pc1ihc$PatientID)]

	dim(mbal.pc1ihc) #[1]  50 236

	# Find median
	mdns      = apply(mbal.pc1ihc,1,median,na.rm=T) # compute median of each row i.e gene
	mdns.df   = as.data.frame(mdns)
	df.mdns   = data.frame(X=rownames(mdns.df),mdns.pc1ihc=mdns.df$mdns) # ER-blanced set based on IHC status alone--- 
	colnames(df.mdns) = c("X",NM.mdns)
	

	# merge this median to PAM50-medians file "mediansPerDataset_v2.txt"
	fl.nm     = paste(PAM50dir,"mediansPerDataset_v2.txt",sep="/")
	fl.mdn    = read.table(fl.nm,sep="\t",header=T,stringsAsFactors=F)

	df.al     = merge(fl.mdn,df.mdns,by="X")

	#save(df.al,file="./Rdat/mediansPerDataset_15Nov17.Rdat")
	write.table(df.al, file=paste(PAM50dir,mdns.outFile,sep="/"), sep="\t", col.names=T,row.names=F,quote=F)

	####
	# run the assignment algorithm
	####

	source(paste(paramDir,"subtypePrediction_functions.R",sep="/"))
	source(paste(paramDir,"subtypePrediction_distributed.R",sep="/"))

	ot.fl     = paste(inputDir,short,"_pam50scores.txt",sep="")
	kl        = read.table(ot.fl,sep="\t",header=T,stringsAsFactors=F)#note md -- for median centered

	df.kl     = data.frame(PatientID=kl$X,Int.SBS.ihcMd=kl$Call,stringsAsFactors=FALSE)
	colnames(df.kl) = c("PatientID",paste("Int.SBS",NM.mdns,sep="."))
	df.kl     = merge(df.kl,df.cln,by="PatientID")
	
	return(list(Int.sbs=df.kl, score.fl=kl, mdns.fl=df.al, SBS.colr = subtypeColors, outList=out, PC1cutoff=df.mis, DF.PC1=df.pca1))
}


makeCalls.v1PAM = function(df.pam = df.pc1pam, seed=118, mat = ml2, NM.mdns="Mdns.v1pam", PAM50dir="./PAM50/bioclassifier_R/", 
			 mdns.outFile = "mediansPerDataset_09May18.txt"){
	message("###df.pam data.frame should have a column --PatientID-- with which mat cols are also named")
	message("##v1PAM subtype column should be named ---PAM50---")
	
	
	ERN.pam = df.pam[which(df.pam$PAM50 %in% c("Basal")),] ### get ER- samples data.frame
	dim(ERN.pam)	#[1] 119   2

	ERP.pam = df.pam[which(df.pam$PAM50 %in% c("LumA")),]
	dim(ERP.pam) #[1] 352   2
	
	set.seed(seed);i = sample(dim(ERP.pam)[1],dim(ERN.pam)[1]) # take equal number of ER+ and ER- samples
	length(ERP.pam$PatientID[i]) # ER positive samples
	length(ERN.pam$PatientID)    # ER negative samples

	######=== subset pam50 matrix with the IDs corresponding to balanced ER+ and ER-
	mbal.pam = mat[,c(ERP.pam$PatientID[i],ERN.pam$PatientID)]

	dim(mbal.pam) #[1]  50 306

	# Find median
	mdns      = apply(mbal.pam,1,median,na.rm=T) # compute median of each row i.e gene
	mdns.df   = as.data.frame(mdns)
	df.mdns   = data.frame(X=rownames(mdns.df),mdns.pam=mdns.df$mdns) # ER-blanced set based on IHC status alone--- 
	colnames(df.mdns) = c("X",NM.mdns)
	

	# merge this median to PAM50-medians file "mediansPerDataset_v2.txt"
	fl.nm     = paste(PAM50dir,"mediansPerDataset_v2.txt",sep="/")
	fl.mdn    = read.table(fl.nm,sep="\t",header=T,stringsAsFactors=F)

	df.al     = merge(fl.mdn,df.mdns,by="X")

	#save(df.al,file="./Rdat/mediansPerDataset_15Nov17.Rdat")
	write.table(df.al, file=paste(PAM50dir,mdns.outFile,sep="/"), sep="\t", col.names=T,row.names=F,quote=F)

	####
	# run the assignment algorithm
	# all the global variable required for assignment algorithm are set outside of function where it is been called
	####

	source(paste(paramDir,"subtypePrediction_functions.R",sep="/"))
	source(paste(paramDir,"subtypePrediction_distributed.R",sep="/"))

	ot.fl     = paste(inputDir,short,"_pam50scores.txt",sep="")
	kl        = read.table(ot.fl,sep="\t",header=T,stringsAsFactors=F)#note md -- for median centered

	df.kl     = data.frame(PatientID=kl$X,Int.SBS.pamMd=kl$Call,stringsAsFactors=FALSE)
	colnames(df.kl) = c("PatientID",paste("Int.SBS",NM.mdns,sep="."))
	df.kl     = merge(df.kl,df.pam[,-which(names(df.pam) %in% c("PAM50"))],by="PatientID") # avoiding PAM50 column

	return(list(Int.sbs=df.kl, score.fl=kl, mdns.fl=df.al, SBS.colr = subtypeColors, outList=out))
}


####function to make calls with provided medians
makeCalls.GivenMdns = function(df.cln = ih.flp, NM.mdns="Given.Mdns"){
	message("###df.cln is for comparison -- columns --PatientID-- with which mat cols are also named")
	message("##IHC subtype column should be named ---IHC---")
	####
	# run the assignment algorithm
	# all the global variable required for assignment algorithm are set outside of function where it is been called
	####
	
	source(paste(paramDir,"subtypePrediction_functions.R",sep="/"))
	source(paste(paramDir,"subtypePrediction_distributed.R",sep="/"))

	ot.fl     = paste(inputDir,short,"_pam50scores.txt",sep="")
	kl        = read.table(ot.fl,sep="\t",header=T,stringsAsFactors=F)#note md -- for median centered

	df.kl     = data.frame(PatientID=kl$X,Int.SBS.ihcMd=kl$Call,stringsAsFactors=FALSE)
	colnames(df.kl) = c("PatientID",paste("Int.SBS",NM.mdns,sep="."))
	df.kl     = merge(df.kl,df.cln,by="PatientID")

	return(list(Int.sbs=df.kl, score.fl=kl, SBS.colr = subtypeColors, outList=out))
}

